import { Component } from '@angular/core';

@Component({
  selector: 'app-tooltip-positions',
  templateUrl: './tooltip-positions.component.html'
})
export class TooltipPositionsComponent  {

  constructor() { }



}
