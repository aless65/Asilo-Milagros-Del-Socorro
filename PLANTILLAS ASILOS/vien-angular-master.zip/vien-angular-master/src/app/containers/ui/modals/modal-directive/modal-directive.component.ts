import { Component} from '@angular/core';

@Component({
  selector: 'app-modal-directive',
  templateUrl: './modal-directive.component.html'
})
export class ModalDirectiveComponent  {

  constructor() { }



}
