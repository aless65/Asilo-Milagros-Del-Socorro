import { Component} from '@angular/core';

@Component({
  selector: 'app-modal-sizes',
  templateUrl: './modal-sizes.component.html'
})
export class ModalSizesComponent {

  constructor() { }



}
