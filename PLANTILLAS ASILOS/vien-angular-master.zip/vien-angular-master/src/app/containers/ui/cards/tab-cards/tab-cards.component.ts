import { Component} from '@angular/core';

@Component({
  selector: 'app-tab-cards',
  templateUrl: './tab-cards.component.html'
})
export class TabCardsComponent {

  constructor() { }



}
