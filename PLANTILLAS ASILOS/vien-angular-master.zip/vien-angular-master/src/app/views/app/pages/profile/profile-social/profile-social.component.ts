import { Component} from '@angular/core';

@Component({
  selector: 'app-profile-social',
  templateUrl: './profile-social.component.html'
})
export class ProfileSocialComponent  {

  constructor() { }



}
