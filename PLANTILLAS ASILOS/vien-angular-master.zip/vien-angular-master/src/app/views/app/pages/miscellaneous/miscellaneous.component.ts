import { Component} from '@angular/core';

@Component({
  selector: 'app-miscellaneous',
  templateUrl: './miscellaneous.component.html'
})
export class MiscellaneousComponent  {

  constructor() { }



}
