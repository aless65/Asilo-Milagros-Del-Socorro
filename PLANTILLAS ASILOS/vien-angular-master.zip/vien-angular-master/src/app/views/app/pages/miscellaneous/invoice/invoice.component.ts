import { Component} from '@angular/core';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html'
})
export class InvoiceComponent  {

  constructor() { }



}
