import { Component} from '@angular/core';

@Component({
  selector: 'app-blank-page',
  templateUrl: './blank-page.component.html'
})
export class BlankPageComponent  {

  constructor() { }



}
