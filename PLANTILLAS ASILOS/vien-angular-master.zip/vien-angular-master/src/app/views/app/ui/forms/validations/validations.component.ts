import { Component } from '@angular/core';

@Component({
  selector: 'app-validations',
  templateUrl: './validations.component.html'
})
export class ValidationsComponent  {

  constructor() { }

}
