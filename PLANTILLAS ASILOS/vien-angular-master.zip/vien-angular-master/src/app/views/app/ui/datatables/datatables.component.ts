import { Component} from '@angular/core';

@Component({
  selector: 'app-datatables',
  templateUrl: './datatables.component.html'
})
export class DatatablesComponent {

  constructor() { }


}
