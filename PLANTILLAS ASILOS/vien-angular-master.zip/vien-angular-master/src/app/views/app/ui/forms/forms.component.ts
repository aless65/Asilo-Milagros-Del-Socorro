import { Component} from '@angular/core';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
})
export class FormsComponent  {

  constructor() { }

}
