import { Component } from '@angular/core';

@Component({
  selector: 'app-maps',
  templateUrl: './maps.component.html'
})
export class MapsComponent  {

  constructor() { }

  mapClicked($event: MouseEvent): void {

  }




}

