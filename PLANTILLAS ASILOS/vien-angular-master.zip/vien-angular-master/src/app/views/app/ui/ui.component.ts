import { Component } from '@angular/core';

@Component({
  selector: 'app-ui',
  templateUrl: './ui.component.html'
})
export class UiComponent  {

  constructor() { }



}
