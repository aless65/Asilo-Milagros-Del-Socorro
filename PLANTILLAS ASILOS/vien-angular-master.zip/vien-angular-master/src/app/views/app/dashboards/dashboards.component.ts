import { Component} from '@angular/core';

@Component({
  selector: 'app-dashboards',
  templateUrl: './dashboards.component.html'
})
export class DashboardsComponent  {

  constructor() { }



}
