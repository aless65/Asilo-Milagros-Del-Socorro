import { Component} from '@angular/core';

@Component({
  selector: 'app-ecommerce',
  templateUrl: './ecommerce.component.html'
})
export class EcommerceComponent  {

  constructor() { }



}
