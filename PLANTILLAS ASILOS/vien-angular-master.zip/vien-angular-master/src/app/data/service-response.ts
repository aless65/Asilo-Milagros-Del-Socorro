export interface IServiceResponse<T> {
    status: boolean;
    data: T[];
}
