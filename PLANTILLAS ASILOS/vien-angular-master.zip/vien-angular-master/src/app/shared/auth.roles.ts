export enum UserRole {
  Editor,
  Admin,
}
